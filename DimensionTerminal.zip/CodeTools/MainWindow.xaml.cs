﻿//=======================================================
//                     
// 
//                  DimensionTerminal
//             Copyright(c)DimensionStudio
//
//=======================================================
//                 维度自研简易控制台框架
//注意：控制台支持扩展程序“TCL”(TerminalConfigLib)为支持控制台运行的基本元素
//请检索当前“TCL”的版本以便于更好的开发您自己的简易控制台
//             (c)Dimension Studio
//
//
//

using DConsole;
using DConsole.Plugin;

using static CodeTools.Login;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System;

namespace CodeTools
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public int FileCount = 0;
        public string command;
        object send = null;
        RoutedEventArgs rou = null;

        public MainWindow()
        {
            InitializeComponent();
            System.Windows.Input.Keyboard.Focus(InputCommand);
            TerminalLevel.ConsoleLevel = Level.Guest;
            TerminalObject.OrdList = "help,consoleInfo,showInfo,clear,writeFile,readFile,rename,mkdir,echo,get,hello,load";   //将每一个指令用字符存储，后面加上“,”表分割
        }

        //注册所需的函数(初始指令)
        public void OnHelp(object sender, EventArgs e)
        {
            if (!File.Exists(@"..\TerminalSettings\Help.txt"))
            {
                MessageBox.Show("[严重错误]：\n[尝试帮助文件文件打开时，发现文件已被移动或者删除]\n[源目录：..\\TerminalSettings\\Help.txt]", "严重的错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                string file = TerminalFile.ReadFile(@"..\TerminalSettings\Help.txt");
                TerminalObject.AppendForConsole(OutPut, file, AssemblyColor.WHITE);
            }
        }
        public void OnThisInfo(object sender, EventArgs e)
        {
            TerminalObject.AppendForConsole(OutPut, TerminalObject.ConsoleInfo);
        }
        public void OnShowInfo(object sender, EventArgs e)
        {
            TerminalObject.AppendForConsole(OutPut, TerminalFile.ReadFile(@"..\TerminalSettings\TerminalInfo.txt"));
        }
        public void OnClear(object sender, EventArgs e)
        {
            TerminalObject.Clear(OutPut);
            TerminalObject.WriteForConsole(OutPut, "DimensionTerminal (c) Dimensionsoft Corporation | 可以输入help查看帮助或者通过菜单中的帮助来获得帮助\r\n———————————————————————————————————————————————————————————————————————————————————————————————————\r\n");
        }
        public void OnWriteFile(object sender, EventArgs e)
        {
            TerminalCommand.COM_writeFile(InputCommand, OutPut, FileCount);
        }
        public void OnReadFile(object sender, EventArgs e)
        {
            TerminalCommand.COM_readFile(InputCommand, OutPut);
        }
        public void OnRename(object sender, EventArgs e)
        {
            TerminalCommand.COM_rename(InputCommand, OutPut);
        }
        public void OnMkdir(object sender, EventArgs e)
        {
            TerminalCommand.COM_mkdir(InputCommand, OutPut);
        }
        public void OnEcho(object sender, EventArgs e)
        {
            TerminalCommand.COM_echo(InputCommand, OutPut);
        }
        public void OnGet(object sender, EventArgs e)
        {
            TerminalCommand.COM_get(InputCommand, OutPut);
        }
        public void OnLoad(object sender, EventArgs e)
        {
            TerminalCommand.COM_load(InputCommand, OutPut);
        }
        public void OnOther(object sender, EventArgs e)
        {
            TObject.ShowErr(OutPut, "[尝试操作一个不存在的操作]： " + InputCommand.Text);
        }
        //注册所需的函数(示例指令)
        public void OnSayHello(object sender, EventArgs e)
        {
            TerminalObject.AppendForConsole(OutPut, "Hello!", AssemblyColor.WHITE);
            TerminalPlugin.LoadPlugin(@"..\TerminalSettings\test.cpi", OutPut);
        }


        /// <summary>
        /// InitRun函数摘要：
        /// <para>负责整个Terminal的命令输入处理</para>
        /// </summary>
        private void InitRun(object sender, RoutedEventArgs e)
        {
            //声明注册变量
            TerminalEvents ordhelp = new TerminalEvents();
            TerminalEvents ordthisInfo = new TerminalEvents();
            TerminalEvents ordshowInfo = new TerminalEvents();
            TerminalEvents ordclear = new TerminalEvents();
            TerminalEvents ordwritefile = new TerminalEvents();
            TerminalEvents ordreadfile = new TerminalEvents();
            TerminalEvents ordrename = new TerminalEvents();
            TerminalEvents ordmkdir = new TerminalEvents();
            TerminalEvents ordecho = new TerminalEvents();
            TerminalEvents ordget = new TerminalEvents();
            TerminalEvents ordload = new TerminalEvents();
            TerminalEvents ordother = new TerminalEvents();
            //注册示例指令变量
            TerminalEvents ordsayhello = new TerminalEvents();


            //注册事件
            ordhelp.RegisterCommandTriggerEvent(OnHelp);
            ordthisInfo.RegisterCommandTriggerEvent(OnThisInfo);
            ordshowInfo.RegisterCommandTriggerEvent(OnShowInfo);
            ordclear.RegisterCommandTriggerEvent(OnClear);
            ordwritefile.RegisterCommandTriggerEvent(OnWriteFile);
            ordreadfile.RegisterCommandTriggerEvent(OnReadFile);
            ordrename.RegisterCommandTriggerEvent(OnRename);
            ordmkdir.RegisterCommandTriggerEvent(OnMkdir);
            ordecho.RegisterCommandTriggerEvent(OnEcho);
            ordget.RegisterCommandTriggerEvent(OnGet);
            ordload.RegisterCommandTriggerEvent(OnLoad);
            ordother.RegisterIsErrorEvent(OnOther);
            //注册示例指令方法
            ordsayhello.RegisterCommandTriggerEvent(OnSayHello);

            if (TerminalAccount.IsRoot)
            {
                TerminalLevel.SetLevel(Level.Root);
            }
            else if (TerminalAccount.IsManager)
            {
                TerminalLevel.SetLevel(Level.Manager);
            }
            command = InputCommand.Text;

            //根据对应条件触发事件
            ordhelp.CommandTrigger(command == "help");
            ordthisInfo.CommandTrigger(command == "thisInfo");
            ordshowInfo.CommandTrigger(command == "consoleInfo");
            ordclear.CommandTrigger(command == "clear");
            ordwritefile.CommandTrigger(command.Contains("writeFile "));
            ordreadfile.CommandTrigger(command.Contains("readFile "));
            ordrename.CommandTrigger(command.Contains("rename "));
            ordmkdir.CommandTrigger(command.Contains("mkdir "));
            ordecho.CommandTrigger(command.Contains("echo "));
            ordget.CommandTrigger(command.Contains("get "));
            ordload.CommandTrigger(command.Contains("load "));
            ordother.OnIsErr(CheckOrd());
            //添加注册指令
            ordsayhello.CommandTrigger(command == "hello");

            CannotInputNull();
            OutPut.ScrollToEnd();
        }

        public bool CheckOrd()
        {
            string[] arr = TerminalObject.GetSplit(TerminalObject.OrdList, ',');
            for(int i = 0; i < arr.Length; i++)
            {
                if (InputCommand.Text.Contains(arr[i]))
                {
                    return true;
                }
            }
            return false;
        }
        
        protected override void OnClosing(CancelEventArgs e)
        {
            SaveLogs(send, rou);
            System.Environment.Exit(0);
        }

        private void InputDone(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                InitRun(send, rou);
            }
        }

        private void RunLogin(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            login.Show();
        }

        private void AboutCodeTools_Click(object sender, RoutedEventArgs e)
        {
            TerminalObject.AppendForConsole(OutPut, TerminalFile.ReadFile(@"..\TerminalSettings\TerminalInfo.txt"));
            OutPut.ScrollToEnd();
        }

        private void ClearBox(object sender, RoutedEventArgs e)
        {
            TerminalObject.Clear(OutPut);
        }

        private void CopyAndOnBox(object sender, RoutedEventArgs e)
        {
            IDataObject data = Clipboard.GetDataObject();
            if (data.GetDataPresent(DataFormats.Text))
            {
                InputCommand.Text = (string)data.GetData(DataFormats.Text);
            }
        }

        private void SaveLogs(object sender, RoutedEventArgs e)
        {
            if (!File.Exists(@"..\TerminalLog\Terminal.log"))
            {
                MessageBox.Show("[严重错误]：\n[尝试对Log文件进行写入时，发现文件已被移动或者删除]\n[源目录：..\\TerminalLog\\Terminal.log]", "严重的错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                TerminalFile.WriteFile(@"..\TerminalLog\Terminal.log", TerminalDebug.Log);
            }
        }

        public void CannotInputNull()
        {
            if(InputCommand.Text == "")
            {
                TObject.ShowErr(OutPut, "[你不能输入一个空指令！]");
            }
        }
    }
}
